const express = require('express');
const router = express.Router();

const Employee = require('../Model/Employee.model');

//Post an Employee
router.post('/', async (req, res, next) =>{
try {
    const employee = new Employee(req.body);
    const result = await employee.save();
    res.send(result);
    
} catch (error) {
    res.send(err.message);
    
}
});


//Get all employee
router.get('/', async (req, res, next) =>{
    try {
        const result = await Employee.find({},{_v: 0});
        res.send(result);
        
    } catch (error) {
        res.send(err.message);
        
    }
    });


// Get employee by id

router.get('/', async (req, res, next) =>{
    const id = req.params.id;
    try {

        const result = await Employee.findById(id);
        res.send(result);

    } catch (error) {
        res.send(err.message);
        
    }
    });



//Patch employee by id

router.patch('/:id', async (req, res, next) =>{
    const id = req.params.id;
    try {
        const id = req.params.id;
        const updatebody = req.body;
        const result = await Employee.findById(id,updatebody);
        res.send;

    } catch (error) {
        res.send(err.message);
        
    }
    });
    
    
    

    router.delete('/:id', async (req, res, next) =>{
        const id = req.params.id;
        try {
          
            const result = await Employee.findByIdDelete(id);
            res.send(" Delete Successful");
    
        } catch (error) {
            res.send(err.message);
            
        }
        });

module.exports = router;

