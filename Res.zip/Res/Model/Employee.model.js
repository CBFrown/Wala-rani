const mongoose = require('mongoose');
const Schema = mongoose.Schema;

     const EmployeeSchema = new Schema({
        fName:{
            type: String,
            required: true
        },
        mName:{
            type: String
        },
        lName:{
            type: String,
            required: true
        },
        age:{
            type: Number,
            min: 18,
            max: 60
        },
        favorite:{
            pet:{type: String},
            car:{type: String},
            food:{type: String}
        },
        dateCreated:{
            type: Date,
            default: Date.now
        }
     });

     const Employee = mongoose.model('employee_information', EmployeeSchema);
     module.exports = Employee;